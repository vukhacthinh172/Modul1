function login() {
    console.log(11);
    // lấy giá trị của ô input
    let emailAddress = document.getElementById("emailAddress").value;
    let password = document.getElementById("password").value;
    let checkItem = document.getElementsByClassName("form-control form-control-lg")
    for (let i = 0; i < checkItem.length; i++) {
        if (checkItem[i].value == "") {
            document.getElementsByClassName("noticeErroLogin")[i].style.display = "block";
        } else {
            document.getElementsByClassName("noticeErroLogin")[i].style.display = "none";

        }
    }
    // lấy dữ liệu từ local về :
    let users = JSON.parse(localStorage.getItem("users")) || [];
    for (let i = 0; i < users.length; i++) {
        if (users[i].yourEmail == emailAddress && users[i].password == password) {
            localStorage.setItem("userId",users[i].id);
            window.location.href = "../index.html"
            return;
        } else {
            /* document.getElementsById("loginErro").innerHTML = "Đăng nhập thất bại !!" */

        }
    }

}